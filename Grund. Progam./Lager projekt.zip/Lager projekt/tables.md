# Names of tables in database explained

> ## basket
> - bId > Basket ID
> - uId > Users ID

> ## basketLine
> - bLId > Basket Line ID
> - iId > Item ID
> - bId > Basket ID

> ## items
> - id > Product ID
> - name > Product Name
> - price > Product Price
> - stock > Product Stock

> ## orderLines
> - oLId > Order Line ID
> - iId > Item ID
> - oId > Order ID

> ## orders
> - id > Order ID
> - uId > User ID

> ## users
> - id > User ID
> - firstName > Users First Name
> - lastName > Users Last Name
> - address > Users Adress
> - city > Users City
> - zipCode > Users Zip Code